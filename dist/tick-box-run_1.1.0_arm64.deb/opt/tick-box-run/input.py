"""Unify D-pad keys and touch/finger events into InputAction values."""

from __future__ import annotations

from enum import Enum, auto

import pygame

from theme import display_to_canvas, to_canvas


class InputAction(Enum):
    UP = auto()
    DOWN = auto()
    A = auto()
    B = auto()
    QUIT = auto()


def event_position(event: pygame.event.Event) -> tuple[int, int] | None:
    if event.type == pygame.MOUSEBUTTONDOWN:
        if getattr(event, "touch", False) or event.button != 1:
            return None
        return display_to_canvas(event.pos)
    if event.type == pygame.FINGERDOWN:
        # Finger positions are fractions of the display, which may be turned.
        return to_canvas(event.x, event.y)
    return None


def actions_from_event(event: pygame.event.Event) -> list[InputAction]:
    """Map a pygame event to zero or more high-level actions.

    Touch position is not converted here; callers use event_position for hit tests.
    Keyboard D-pad / A / B map directly.
    """
    if event.type == pygame.QUIT:
        return [InputAction.QUIT]

    if event.type != pygame.KEYDOWN:
        return []

    key = event.key
    # Escape always leaves the program, from any screen or a live ride.
    if key == pygame.K_ESCAPE:
        return [InputAction.QUIT]
    if key in (pygame.K_UP, pygame.K_w):
        return [InputAction.UP]
    if key in (pygame.K_DOWN, pygame.K_s):
        return [InputAction.DOWN]
    if key in (pygame.K_RIGHT, pygame.K_RETURN, pygame.K_SPACE, pygame.K_x):
        return [InputAction.A]
    if key in (pygame.K_LEFT, pygame.K_z, pygame.K_BACKSPACE):
        return [InputAction.B]
    return []
